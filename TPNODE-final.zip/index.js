import express from 'express'
import peliculaController from './src/controllers/peliculaController.js'
import userController from './src/controllers/userController.js'
import personajeController from './src/controllers/personajeController.js'
import cors from 'cors';

const app = express();

const port = 4000;
app.use(cors());
app.use(express.json());
app.set('port', port);

//console.log("server en el puerto: ",app.get('port'));

app.use("/Pelicula", peliculaController);
app.use("/Personaje", personajeController);
app.use("/auth/login", userController);
app.listen(port, () => {
    console.log(`Listening on port ${port}`)
  })


export default app;