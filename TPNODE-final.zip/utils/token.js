import jwt from "jsonwebtoken";
import 'dotenv/config'


export const generateJWT = () => {

    
    return new Promise((resolve, reject) => {

        const validation = {valid: true}
        
        jwt.sign(validation, process.env.JWT_SECRET_KEY, {expiresIn: '300s'}, (err, token) => {
            
            if (err) {
                console.log(err)
                reject('Failed to generate token')
            } else {
                resolve(token)
            }
        
        })

    })
}