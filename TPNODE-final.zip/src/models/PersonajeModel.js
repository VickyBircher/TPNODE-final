class Personaje{
    id;
    imagen;
    nombre;
    edad;
    peso;
    historia;
    PoS;
}

export default Personaje;