class Pelicula{
    id;
    imagen;
    titulo;
    fecha;
    calificacion;
    PsA;
}
export default Pelicula;