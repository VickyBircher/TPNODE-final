class User{
    id;
    nombre;
    contraseña;
    token;
}

export default User;