import config from '../dbconfig.js';
import sql from 'mssql';

class PersonajeService{
    getAll = async ()=>{
        let personajes = null
        try{
            let pool = await sql.connect(config);
            const result = await pool.request()
                                     .query('SELECT * FROM Personaje');
            personajes = result.recordsets;    
        }catch(error){
            console.log(error);
        }
        return personajes;
    }

    getPeliculaById = async (id)=>{
        let personajes = null;
        try {
            let pool    = await sql.connect(config);
            let result  = await pool.request()
                                .input ('pId', sql.Int, id)
                                .query ('SELECT * FROM Personaje WHERE id = @pId');
            personajes = result.recordsets [0][0];
        } catch (error){
            console.log(error);
        }
        return personajes;
    }

    insertPersonaje = async (personaje)=>{

        let returnEntity = null;
        // hacer que la fecha creacion se ponga sin el usuario
            try {
                let pool    = await sql.connect(config);
                let result  = await pool.request()
                                    .input ('pImagen', sql.VarChar(255), personaje.imagen)
                                    .input ('pNombre', sql.VarChar(50), personaje.nombre)
                                    .input ('pEdad', sql.Int, personaje.edad)
                                    .input ('pPeso', sql.Float, personaje.peso)
                                    .input ('pHistoria', sql.VarChar(255), personaje.historia)
                                    .query (`INSERT INTO Personaje (imagen, nombre, edad, peso, historia)
                                            VALUES (@pImagen, @pNombre, @pEdad, @pPeso, @pHistoria)`);
                returnEntity = result.recordsets;
            }
            catch(error){
                console.log(error);
            }
            return returnEntity;
    }

    updatePersonaje = async (personaje)=>{
        let returnEntity = null;
        try{
            let pool    = await sql.connect(config);
            let result  = await pool.request()
            .input ('pImagen', sql.VarChar(255), personaje.imagen)
            .input ('pNombre', sql.VarChar(50), personaje.nombre)
            .input ('pEdad', sql.Int, personaje.edad)
            .input ('pPeso', sql.Float, personaje.peso)
            .input ('pHistoria', sql.VarChar(255), personaje.historia)
            .query (`UPDATE INTO Personaje (imagen, nombre, edad, peso, historia)
                    VALUES (@pImagen, @pNombre, @pEdad, @pPeso, @pHistoria)`);
                returnEntity = result.recordsets;
        }
        catch(error){
            console.log(error);
        }
        return returnEntity;
    }

    
    deleteById= async (id)=>{
        let rowsAffected = 0;
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
                                        .input('pId', sql.Int, id)
                                        .query("DELETE FROM Personaje WHERE Id=@pId");
            rowsAffected = result.rowsAffected;
        } catch (error){
            console.log(error);
        }
        return rowsAffected;
    }

}
export default PersonajeService;