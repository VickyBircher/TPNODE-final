import config from '../dbconfig.js';
import sql from 'mssql';

class UserService {
    searchUser = async (user, password)=>{
        let rta = null
        try{
            let pool = await sql.connect(config);
            const result = await pool.request()
                                    .input ('pNombre', sql.VarChar(50), user)
                                    .input ('pContrasenia', sql.VarChar(50), password)
                                    .query('SELECT * FROM Usuario WHERE Nombre = @pNombre AND Contrasenia = @pContrasenia');
            rta = result.recordsets [0];    
        }catch(error){
            console.log(error);
        }
        return rta;
    }

}
export default UserService;