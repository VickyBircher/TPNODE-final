import config from '../dbconfig.js';
import sql from 'mssql';

class UserService{
    getAll = async (user, password)=>{
        let user = null
        try{
            let pool = await sql.connect(config);
            const result = await pool.request()
                                    .input ('pNombre', sql.VarChar(50), user)
                                    .input ('pContraenia', sql.VarChar(50), password)
                                    .query('SELECT * FROM Usuario WHERE user = @Nombre AND password = @pContrasenia');
            user = result.recordsets [0];    
        }catch(error){
            console.log(error);
        }
        return user;
    }

}
export default PersonajeService;