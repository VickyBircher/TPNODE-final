import { Router } from "express";
import PeliculaServices from "../services/PeliculaServices.js";
import Pelicula from '../models/PeliculaModel.js'

const router = Router();
const peliculaServices = new PeliculaServices();
const pelicula = new Pelicula();

router.get('', async(req,res)=>{
    try{

        const pelicula = await PeliculaServices.getAll();
        return res.status(200).json(pelicula);
    
    } catch (error){
        return res.status(400).send('Error.');
    }
});

router.get('/:id', async (req,res)=>{
    try{
        const {id} = req.params;
        const pelicula = await PeliculaServices.getPeliculaById(req.params.id);
        return res.status(200).json(pelicula);
    
    } catch (error) {
        return res.status(400).send('Error.');
    }
});

router.post('/:id', async (req,res)=>{
    try{
        const pelicula = req.body;
        const peliculaInsert = PeliculaServices.insertPelicula(pelicula);
        return res.status(200).json(peliculaInsert);  
    } catch (error) {
        return res.status(400).send('Error.');
    }
});

router.put('/:id',async(req,res)=>{
    try{
        let pelicula = req.body;
        const peliculaUpdate = await PeliculaServices.updatePelicula(pelicula);
        return res.status(200).json(peliculaUpdate);
    } catch (error){
        return res.status(400).send('Error');
    }
})

router.delete('/:id', async(req,res)=>{
    try{
        const pizzaDelete = await PeliculaServices.deleteById(req.params['id']);
        return res.status(200).send('Película eliminada.');
    }catch(error){
        return res.status(400).send('Error');
    }
    
})
export default router;