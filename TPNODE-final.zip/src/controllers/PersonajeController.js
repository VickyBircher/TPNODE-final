import { Router } from "express";
import PersonajeService from "../services/PersonajeServices.js";
import Personaje from "../models/PersonajeModel.js";

const router = Router();
const personajeController = new PersonajeService();
const personaje = new Personaje();

router.get('', async(req,res)=>{
    try{

        const personaje = await PeliculaService.getAll();
        return res.status(200).json(personaje);
    
    } catch (error){
        return res.status(400).send('Error.');
    }
});

router.get('/:id', async (req,res)=>{
    try{
        const {id} = req.params;
        const personaje = await PersonajeService.getPersonajeById(req.params.id);
        return res.status(200).json(personaje);
    
    } catch (error) {
        return res.status(400).send('Error.');
    }
});

router.post('/:id', async (req,res)=>{
    try{
        const personaje = req.body;
        const personajeInsert = PersonajeService.insertPersonaje(personaje);
        return res.status(200).json(personajeInsert);  
    } catch (error) {
        return res.status(400).send('Error.');
    }
});

router.put('/:id',async(req,res)=>{
    try{
        let personaje = req.body;
        const personajeUpdate = await PersonajeService.updatePersonaje(personaje);
        return res.status(200).json(personajeUpdate);
    } catch (error){
        return res.status(400).send('Error');
    }
})

router.delete('/:id', async(req,res)=>{
    try{
        const personajeDelete = await PersonajeService.deleteById(req.params['id']);
        return res.status(200).send('Personaje eliminado.');
    }catch(error){
        return res.status(400).send('Error');
    }
    
})
export default router;