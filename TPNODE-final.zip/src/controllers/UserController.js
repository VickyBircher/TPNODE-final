import { Router } from "express";
import jwt from "jsonwebtoken";
import UserService from '../services/UserServices.js';

const router = Router();
const userService = new UserService();

router.post('', async (req, res) => {
    try{
        const {user,password} = req.body;
        const Token = await userService.searchUser(user, password);
        if(Token == null) {
            return res.status(404).send('usuario o contraseña incorrectos');
        }
        jwt.sign({user: Token},'secretkey',  {expiresIn: '300s'},(err, token)=>{
            res.json({
                token: token
            })
        })
    } catch(error){
        console.log(error);
    }
})

export default router;